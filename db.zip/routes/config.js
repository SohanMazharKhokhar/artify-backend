// apiConfig.js
export const BASE_URL = 'http://192.168.0.110:5000/api/auth';
