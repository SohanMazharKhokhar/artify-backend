// // // // routes/products.js
// // // const express = require('express');
// // // const router = express.Router();

// // // // Assuming you placed the products array in 'data/products.js'
// // // // If you put the array directly here, you can skip this require
// // // const allProducts = require('../data/products'); // Adjust path if needed

// // // // GET /api/products - Get all products with optional filtering and searching
// // // router.get('/', (req, res) => {
// // //   let { type, search } = req.query;
// // //   let filteredProducts = [...allProducts]; // Start with all products

// // //   // Apply category filter
// // //   if (type && type.toLowerCase() !== 'all') {
// // //     filteredProducts = filteredProducts.filter(p => p.type.toLowerCase() === type.toLowerCase());
// // //   }

// // //   // Apply search filter (searches name and type)
// // //   if (search) {
// // //     const searchQueryLower = search.toLowerCase();
// // //     filteredProducts = filteredProducts.filter(p =>
// // //       p.name.toLowerCase().includes(searchQueryLower) ||
// // //       p.type.toLowerCase().includes(searchQueryLower)
// // //     );
// // //   }

// // //   res.json(filteredProducts);
// // // });

// // // // GET /api/products/:id - Get a single product by ID (optional, but good practice)
// // // router.get('/:id', (req, res) => {
// // //   const productId = parseInt(req.params.id, 10);
// // //   const product = allProducts.find(p => p.id === productId);

// // //   if (product) {
// // //     res.json(product);
// // //   } else {
// // //     res.status(404).json({ message: 'Product not found' });
// // //   }
// // // });
// // // // data/products.js (Optional: or place this array directly in routes/products.js)
// // // const products = [
// // //   // T-Shirts (10)
// // //   {
// // //     id: 101,
// // //     name: 'Custom Summer Shirt - Tropical',
// // //     price: 899,
// // //     type: 'T-Shirts',
// // //     image: 'https://images.pexels.com/photos/9558699/pexels-photo-9558699.jpeg',
// // //   },
// // //   {
// // //     id: 102,
// // //     name: 'Custom Summer Shirt - Beach',
// // //     price: 799,
// // //     type: 'T-Shirts',
// // //     image: 'https://images.pexels.com/photos/428338/pexels-photo-428338.jpeg',
// // //   },
// // //   {
// // //     id: 103,
// // //     name: 'Custom Summer Shirt - Sunset',
// // //     price: 849,
// // //     type: 'T-Shirts',
// // //     image: 'https://images.pexels.com/photos/1021291/pexels-photo-1021291.jpeg',
// // //   },
// // //   {
// // //     id: 104,
// // //     name: 'Custom Summer Shirt - Palm',
// // //     price: 749,
// // //     type: 'T-Shirts',
// // //     image: 'https://images.pexels.com/photos/934070/pexels-photo-934070.jpeg',
// // //   },
// // //   {
// // //     id: 105,
// // //     name: 'Custom Summer Shirt - Wave',
// // //     price: 999,
// // //     type: 'T-Shirts',
// // //     image: 'https://images.pexels.com/photos/1484807/pexels-photo-1484807.jpeg',
// // //   },
// // //   {
// // //     id: 106,
// // //     name: 'Custom Summer Shirt - Surf',
// // //     price: 899,
// // //     type: 'T-Shirts',
// // //     image: 'https://images.pexels.com/photos/3631430/pexels-photo-3631430.jpeg',
// // //   },
// // //   {
// // //     id: 107,
// // //     name: 'Custom Summer Shirt - Island',
// // //     price: 799,
// // //     type: 'T-Shirts',
// // //     image: 'https://images.pexels.com/photos/325521/pexels-photo-325521.jpeg',
// // //   },
// // //   {
// // //     id: 108,
// // //     name: 'Custom Summer Shirt - Coconut',
// // //     price: 949,
// // //     type: 'T-Shirts',
// // //     image: 'https://images.pexels.com/photos/3731256/pexels-photo-3731256.jpeg',
// // //   },
// // //   {
// // //     id: 109,
// // //     name: 'Custom Summer Shirt - Ocean',
// // //     price: 899,
// // //     type: 'T-Shirts',
// // //     image: 'https://images.pexels.com/photos/326055/pexels-photo-326055.jpeg',
// // //   },
// // //   {
// // //     id: 110,
// // //     name: 'Custom Summer Shirt - Sand',
// // //     price: 699,
// // //     type: 'T-Shirts',
// // //     image: 'https://images.pexels.com/photos/1032110/pexels-photo-1032110.jpeg',
// // //   },

// // //   // Mugs (10) - Nescafe Style
// // //   {
// // //     id: 201,
// // //     name: 'Classic Coffee Mug',
// // //     price: 349,
// // //     type: 'Mugs',
// // //     image: 'https://images.pexels.com/photos/4792391/pexels-photo-4792391.jpeg',
// // //   },
// // //   {
// // //     id: 202,
// // //     name: 'Nescafe Gold Mug',
// // //     price: 399,
// // //     type: 'Mugs',
// // //     image: 'https://images.pexels.com/photos/851555/pexels-photo-851555.jpeg',
// // //   },
// // //   {
// // //     id: 203,
// // //     name: 'Minimalist Coffee Mug',
// // //     price: 299,
// // //     type: 'Mugs',
// // //     image: 'https://images.pexels.com/photos/312418/pexels-photo-312418.jpeg',
// // //   },
// // //   {
// // //     id: 204,
// // //     name: 'Vintage Nescafe Mug',
// // //     price: 449,
// // //     type: 'Mugs',
// // //     image: 'https://images.pexels.com/photos/905485/pexels-photo-905485.jpeg',
// // //   },
// // //   {
// // //     id: 205,
// // //     name: 'Ceramic Coffee Mug',
// // //     price: 379,
// // //     type: 'Mugs',
// // //     image: 'https://images.pexels.com/photos/1727123/pexels-photo-1727123.jpeg',
// // //   },
// // //   {
// // //     id: 206,
// // //     name: 'Black Nescafe Mug',
// // //     price: 499,
// // //     type: 'Mugs',
// // //     image: 'https://images.pexels.com/photos/887751/pexels-photo-887751.jpeg',
// // //   },
// // //   {
// // //     id: 207,
// // //     name: 'Glass Coffee Mug',
// // //     price: 599,
// // //     type: 'Mugs',
// // //     image: 'https://images.pexels.com/photos/302899/pexels-photo-302899.jpeg',
// // //   },
// // //   {
// // //     id: 208,
// // //     name: 'Travel Coffee Mug',
// // //     price: 699,
// // //     type: 'Mugs',
// // //     image: 'https://images.pexels.com/photos/2253275/pexels-photo-2253275.jpeg',
// // //   },
// // //   {
// // //     id: 209,
// // //     name: 'Espresso Nescafe Mug',
// // //     price: 549,
// // //     type: 'Mugs',
// // //     image: 'https://images.pexels.com/photos/5587028/pexels-photo-5587028.jpeg',
// // //   },
// // //   {
// // //     id: 210,
// // //     name: 'Double-Wall Coffee Mug',
// // //     price: 649,
// // //     type: 'Mugs',
// // //     image: 'https://images.pexels.com/photos/374147/pexels-photo-374147.jpeg',
// // //   },

// // //   // Posters (10)
// // //   {
// // //     id: 301,
// // //     name: 'Vintage Movie Poster',
// // //     price: 499,
// // //     type: 'Posters',
// // //     image: 'https://images.pexels.com/photos/33129/popcorn-movie-party-entertainment.jpg',
// // //   },
// // //   {
// // //     id: 302,
// // //     name: 'Motivational Quote Poster',
// // //     price: 399,
// // //     type: 'Posters',
// // //     image: 'https://images.pexels.com/photos/733856/pexels-photo-733856.jpeg',
// // //   },
// // //   {
// // //     id: 303,
// // //     name: 'Space Exploration Poster',
// // //     price: 599,
// // //     type: 'Posters',
// // //     image: 'https://images.pexels.com/photos/2150/sky-space-dark-galaxy.jpg',
// // //   },
// // //   {
// // //     id: 304,
// // //     name: 'Abstract Art Poster',
// // //     price: 449,
// // //     type: 'Posters',
// // //     image: 'https://images.pexels.com/photos/1021876/pexels-photo-1021876.jpeg',
// // //   },
// // //   {
// // //     id: 305,
// // //     name: 'Travel Destination Poster',
// // //     price: 549,
// // //     type: 'Posters',
// // //     image: 'https://images.pexels.com/photos/672532/pexels-photo-672532.jpeg',
// // //   },
// // //   {
// // //     id: 306,
// // //     name: 'Music Band Poster',
// // //     price: 499,
// // //     type: 'Posters',
// // //     image: 'https://images.pexels.com/photos/167491/pexels-photo-167491.jpeg',
// // //   },
// // //   {
// // //     id: 307,
// // //     name: 'Minimalist Landscape Poster',
// // //     price: 399,
// // //     type: 'Posters',
// // //     image: 'https://images.pexels.com/photos/417074/pexels-photo-417074.jpeg',
// // //   },
// // //   {
// // //     id: 308,
// // //     name: 'Wildlife Photography Poster',
// // //     price: 649,
// // //     type: 'Posters',
// // //     image: 'https://images.pexels.com/photos/145939/pexels-photo-145939.jpeg',
// // //   },
// // //   {
// // //     id: 309,
// // //     name: 'Retro Gaming Poster',
// // //     price: 599,
// // //     type: 'Posters',
// // //     image: 'https://images.pexels.com/photos/163036/mario-luigi-yoschi-figures-163036.jpeg',
// // //   },
// // //   {
// // //     id: 310,
// // //     name: 'Galaxy Nebula Poster',
// // //     price: 699,
// // //     type: 'Posters',
// // //     image: 'https://images.pexels.com/photos/2150/sky-space-dark-galaxy.jpg',
// // //   },

// // //   // Stickers (10)
// // //   {
// // //     id: 401,
// // //     name: 'Funny Cat Sticker Pack',
// // //     price: 199,
// // //     type: 'Stickers',
// // //     image: 'https://images.pexels.com/photos/617278/pexels-photo-617278.jpeg',
// // //   },
// // //   {
// // //     id: 402,
// // //     name: 'Boho Floral Stickers',
// // //     price: 149,
// // //     type: 'Stickers',
// // //     image: 'https://images.pexels.com/photos/462118/pexels-photo-462118.jpeg',
// // //   },
// // //   {
// // //     id: 403,
// // //     name: 'Space-Themed Stickers',
// // //     price: 249,
// // //     type: 'Stickers',
// // //     image: 'https://images.pexels.com/photos/2150/sky-space-dark-galaxy.jpg',
// // //   },
// // //   {
// // //     id: 404,
// // //     name: 'Waterproof Laptop Stickers',
// // //     price: 299,
// // //     type: 'Stickers',
// // //     image: 'https://images.pexels.com/photos/1591447/pexels-photo-1591447.jpeg',
// // //   },
// // //   {
// // //     id: 405,
// // //     name: 'Vinyl Decal Stickers',
// // //     price: 179,
// // //     type: 'Stickers',
// // //     image: 'https://images.pexels.com/photos/159711/books-bookstore-book-reading-159711.jpeg',
// // //   },
// // //   {
// // //     id: 406,
// // //     name: 'Cartoon Character Stickers',
// // //     price: 219,
// // //     type: 'Stickers',
// // //     image: 'https://images.pexels.com/photos/161559/background-bitter-breakfast-bright-161559.jpeg',
// // //   },
// // //   {
// // //     id: 407,
// // //     name: 'Glow-in-the-Dark Stickers',
// // //     price: 349,
// // //     type: 'Stickers',
// // //     image: 'https://images.pexels.com/photos/1021876/pexels-photo-1021876.jpeg',
// // //   },
// // //   {
// // //     id: 408,
// // //     name: 'Holographic Sticker Pack',
// // //     price: 399,
// // //     type: 'Stickers',
// // //     image: 'https://images.pexels.com/photos/3266700/pexels-photo-3266700.jpeg',
// // //   },
// // //   {
// // //     id: 409,
// // //     name: 'Custom Name Stickers',
// // //     price: 279,
// // //     type: 'Stickers',
// // //     image: 'https://images.pexels.com/photos/2735981/pexels-photo-2735981.jpeg',
// // //   },
// // //   {
// // //     id: 410,
// // //     name: 'Emoji Sticker Collection',
// // //     price: 199,
// // //     type: 'Stickers',
// // //     image: 'https://images.pexels.com/photos/2377565/pexels-photo-2377565.jpeg',
// // //   },
// // // ];

// // // module.exports = products;
// // // module.exports = router;
// // const express = require('express');
// // const router = express.Router();

// // const products = [
// //   // T-Shirts (10)
// //   {
// //     id: 101,
// //     name: 'Custom Summer Shirt - Tropical',
// //     price: 899,
// //     type: 'T-Shirts',
// //     image: 'https://images.pexels.com/photos/9558699/pexels-photo-9558699.jpeg',
// //   },
// //   {
// //     id: 102,
// //     name: 'Custom Summer Shirt - Beach',
// //     price: 799,
// //     type: 'T-Shirts',
// //     image: 'https://images.pexels.com/photos/428338/pexels-photo-428338.jpeg',
// //   },
// //   {
// //     id: 103,
// //     name: 'Custom Summer Shirt - Sunset',
// //     price: 849,
// //     type: 'T-Shirts',
// //     image: 'https://images.pexels.com/photos/1021291/pexels-photo-1021291.jpeg',
// //   },
// //   {
// //     id: 104,
// //     name: 'Custom Summer Shirt - Palm',
// //     price: 749,
// //     type: 'T-Shirts',
// //     image: 'https://images.pexels.com/photos/934070/pexels-photo-934070.jpeg',
// //   },
// //   {
// //     id: 105,
// //     name: 'Custom Summer Shirt - Wave',
// //     price: 999,
// //     type: 'T-Shirts',
// //     image: 'https://images.pexels.com/photos/1484807/pexels-photo-1484807.jpeg',
// //   },
// //   {
// //     id: 106,
// //     name: 'Custom Summer Shirt - Surf',
// //     price: 899,
// //     type: 'T-Shirts',
// //     image: 'https://images.pexels.com/photos/3631430/pexels-photo-3631430.jpeg',
// //   },
// //   {
// //     id: 107,
// //     name: 'Custom Summer Shirt - Island',
// //     price: 799,
// //     type: 'T-Shirts',
// //     image: 'https://images.pexels.com/photos/325521/pexels-photo-325521.jpeg',
// //   },
// //   {
// //     id: 108,
// //     name: 'Custom Summer Shirt - Coconut',
// //     price: 949,
// //     type: 'T-Shirts',
// //     image: 'https://images.pexels.com/photos/3731256/pexels-photo-3731256.jpeg',
// //   },
// //   {
// //     id: 109,
// //     name: 'Custom Summer Shirt - Ocean',
// //     price: 899,
// //     type: 'T-Shirts',
// //     image: 'https://images.pexels.com/photos/326055/pexels-photo-326055.jpeg',
// //   },
// //   {
// //     id: 110,
// //     name: 'Custom Summer Shirt - Sand',
// //     price: 699,
// //     type: 'T-Shirts',
// //     image: 'https://images.pexels.com/photos/1032110/pexels-photo-1032110.jpeg',
// //   },

// //   // Mugs (10) - Nescafe Style
// //   {
// //     id: 201,
// //     name: 'Classic Coffee Mug',
// //     price: 349,
// //     type: 'Mugs',
// //     image: 'https://images.pexels.com/photos/4792391/pexels-photo-4792391.jpeg',
// //   },
// //   {
// //     id: 202,
// //     name: 'Nescafe Gold Mug',
// //     price: 399,
// //     type: 'Mugs',
// //     image: 'https://images.pexels.com/photos/851555/pexels-photo-851555.jpeg',
// //   },
// //   {
// //     id: 203,
// //     name: 'Minimalist Coffee Mug',
// //     price: 299,
// //     type: 'Mugs',
// //     image: 'https://images.pexels.com/photos/312418/pexels-photo-312418.jpeg',
// //   },
// //   {
// //     id: 204,
// //     name: 'Vintage Nescafe Mug',
// //     price: 449,
// //     type: 'Mugs',
// //     image: 'https://images.pexels.com/photos/905485/pexels-photo-905485.jpeg',
// //   },
// //   {
// //     id: 205,
// //     name: 'Ceramic Coffee Mug',
// //     price: 379,
// //     type: 'Mugs',
// //     image: 'https://images.pexels.com/photos/1727123/pexels-photo-1727123.jpeg',
// //   },
// //   {
// //     id: 206,
// //     name: 'Black Nescafe Mug',
// //     price: 499,
// //     type: 'Mugs',
// //     image: 'https://images.pexels.com/photos/887751/pexels-photo-887751.jpeg',
// //   },
// //   {
// //     id: 207,
// //     name: 'Glass Coffee Mug',
// //     price: 599,
// //     type: 'Mugs',
// //     image: 'https://images.pexels.com/photos/302899/pexels-photo-302899.jpeg',
// //   },
// //   {
// //     id: 208,
// //     name: 'Travel Coffee Mug',
// //     price: 699,
// //     type: 'Mugs',
// //     image: 'https://images.pexels.com/photos/2253275/pexels-photo-2253275.jpeg',
// //   },
// //   {
// //     id: 209,
// //     name: 'Espresso Nescafe Mug',
// //     price: 549,
// //     type: 'Mugs',
// //     image: 'https://images.pexels.com/photos/5587028/pexels-photo-5587028.jpeg',
// //   },
// //   {
// //     id: 210,
// //     name: 'Double-Wall Coffee Mug',
// //     price: 649,
// //     type: 'Mugs',
// //     image: 'https://images.pexels.com/photos/374147/pexels-photo-374147.jpeg',
// //   },

// //   // Posters (10)
// //   {
// //     id: 301,
// //     name: 'Vintage Movie Poster',
// //     price: 499,
// //     type: 'Posters',
// //     image: 'https://images.pexels.com/photos/33129/popcorn-movie-party-entertainment.jpg',
// //   },
// //   {
// //     id: 302,
// //     name: 'Motivational Quote Poster',
// //     price: 399,
// //     type: 'Posters',
// //     image: 'https://images.pexels.com/photos/733856/pexels-photo-733856.jpeg',
// //   },
// //   {
// //     id: 303,
// //     name: 'Space Exploration Poster',
// //     price: 599,
// //     type: 'Posters',
// //     image: 'https://images.pexels.com/photos/2150/sky-space-dark-galaxy.jpg',
// //   },
// //   {
// //     id: 304,
// //     name: 'Abstract Art Poster',
// //     price: 449,
// //     type: 'Posters',
// //     image: 'https://images.pexels.com/photos/1021876/pexels-photo-1021876.jpeg',
// //   },
// //   {
// //     id: 305,
// //     name: 'Travel Destination Poster',
// //     price: 549,
// //     type: 'Posters',
// //     image: 'https://images.pexels.com/photos/672532/pexels-photo-672532.jpeg',
// //   },
// //   {
// //     id: 306,
// //     name: 'Music Band Poster',
// //     price: 499,
// //     type: 'Posters',
// //     image: 'https://images.pexels.com/photos/167491/pexels-photo-167491.jpeg',
// //   },
// //   {
// //     id: 307,
// //     name: 'Minimalist Landscape Poster',
// //     price: 399,
// //     type: 'Posters',
// //     image: 'https://images.pexels.com/photos/417074/pexels-photo-417074.jpeg',
// //   },
// //   {
// //     id: 308,
// //     name: 'Wildlife Photography Poster',
// //     price: 649,
// //     type: 'Posters',
// //     image: 'https://images.pexels.com/photos/145939/pexels-photo-145939.jpeg',
// //   },
// //   {
// //     id: 309,
// //     name: 'Retro Gaming Poster',
// //     price: 599,
// //     type: 'Posters',
// //     image: 'https://images.pexels.com/photos/163036/mario-luigi-yoschi-figures-163036.jpeg',
// //   },
// //   {
// //     id: 310,
// //     name: 'Galaxy Nebula Poster',
// //     price: 699,
// //     type: 'Posters',
// //     image: 'https://images.pexels.com/photos/2150/sky-space-dark-galaxy.jpg',
// //   },

// //   // Stickers (10)
// //   {
// //     id: 401,
// //     name: 'Funny Cat Sticker Pack',
// //     price: 199,
// //     type: 'Stickers',
// //     image: 'https://images.pexels.com/photos/617278/pexels-photo-617278.jpeg',
// //   },
// //   {
// //     id: 402,
// //     name: 'Boho Floral Stickers',
// //     price: 149,
// //     type: 'Stickers',
// //     image: 'https://images.pexels.com/photos/462118/pexels-photo-462118.jpeg',
// //   },
// //   {
// //     id: 403,
// //     name: 'Space-Themed Stickers',
// //     price: 249,
// //     type: 'Stickers',
// //     image: 'https://images.pexels.com/photos/2150/sky-space-dark-galaxy.jpg',
// //   },
// //   {
// //     id: 404,
// //     name: 'Waterproof Laptop Stickers',
// //     price: 299,
// //     type: 'Stickers',
// //     image: 'https://images.pexels.com/photos/1591447/pexels-photo-1591447.jpeg',
// //   },
// //   {
// //     id: 405,
// //     name: 'Vinyl Decal Stickers',
// //     price: 179,
// //     type: 'Stickers',
// //     image: 'https://images.pexels.com/photos/159711/books-bookstore-book-reading-159711.jpeg',
// //   },
// //   {
// //     id: 406,
// //     name: 'Cartoon Character Stickers',
// //     price: 219,
// //     type: 'Stickers',
// //     image: 'https://images.pexels.com/photos/161559/background-bitter-breakfast-bright-161559.jpeg',
// //   },
// //   {
// //     id: 407,
// //     name: 'Glow-in-the-Dark Stickers',
// //     price: 349,
// //     type: 'Stickers',
// //     image: 'https://images.pexels.com/photos/1021876/pexels-photo-1021876.jpeg',
// //   },
// //   {
// //     id: 408,
// //     name: 'Holographic Sticker Pack',
// //     price: 399,
// //     type: 'Stickers',
// //     image: 'https://images.pexels.com/photos/3266700/pexels-photo-3266700.jpeg',
// //   },
// //   {
// //     id: 409,
// //     name: 'Custom Name Stickers',
// //     price: 279,
// //     type: 'Stickers',
// //     image: 'https://images.pexels.com/photos/2735981/pexels-photo-2735981.jpeg',
// //   },
// //   {
// //     id: 410,
// //     name: 'Emoji Sticker Collection',
// //     price: 199,
// //     type: 'Stickers',
// //     image: 'https://images.pexels.com/photos/2377565/pexels-photo-2377565.jpeg',
// //   },
// // ];

// //   // Add more products here if needed


// // router.get('/', (req, res) => {
// //   res.json(products);
// // });

// // module.exports = router;
// const express = require('express');
// const router = express.Router();
// const allProducts = require('../data/products');

// // GET /api/products - Get all products with optional filtering and searching
// router.get('/', (req, res) => {
//   let { type, search } = req.query;
//   let filteredProducts = [...allProducts];

//   if (type && type.toLowerCase() !== 'all') {
//     filteredProducts = filteredProducts.filter(p => p.type.toLowerCase() === type.toLowerCase());
//   }

//   if (search) {
//     const searchQueryLower = search.toLowerCase();
//     filteredProducts = filteredProducts.filter(p =>
//       p.name.toLowerCase().includes(searchQueryLower) ||
//       p.type.toLowerCase().includes(searchQueryLower)
//     );
//   }

//   res.json(filteredProducts);
// });

// // GET single product by ID
// router.get('/:id', (req, res) => {
//   const productId = parseInt(req.params.id, 10);
//   const product = allProducts.find(p => p.id === productId);

//   if (product) {
//     res.json(product);
//   } else {
//     res.status(404).json({ message: 'Product not found' });
//   }
// });

// module.exports = router;
// routes/products.js
const express = require('express');
const router = express.Router();
const Product = require('../models/Product'); // Import the Product Mongoose model

// Seed initial products (for demonstration, you can remove this after first run)
const seedProducts = async () => {
  try {
    const count = await Product.countDocuments();
    if (count === 0) {
      const initialProducts = [
  // T-Shirts (10)
  
  {
    id: 105,
    name: 'Custom Summer Shirt - Wave',
    price: 999,
    type: 'T-Shirts',
    image: 'https://images.pexels.com/photos/1484807/pexels-photo-1484807.jpeg',
  },
  {
    id: 106,
    name: 'Custom Summer Shirt - Surf',
    price: 899,
    type: 'T-Shirts',
    image: 'https://images.pexels.com/photos/3631430/pexels-photo-3631430.jpeg',
  },
  {
    id: 107,
    name: 'Custom Summer Shirt - Island',
    price: 799,
    type: 'T-Shirts',
    image: 'https://images.pexels.com/photos/325521/pexels-photo-325521.jpeg',
  },
  {
    id: 108,
    name: 'Custom Summer Shirt - Coconut',
    price: 949,
    type: 'T-Shirts',
    image: 'https://images.pexels.com/photos/3731256/pexels-photo-3731256.jpeg',
  },
  {
    id: 109,
    name: 'Custom Summer Shirt - Ocean',
    price: 899,
    type: 'T-Shirts',
    image: 'https://images.pexels.com/photos/326055/pexels-photo-326055.jpeg',
  },
  {
    id: 110,
    name: 'Custom Summer Shirt - Sand',
    price: 699,
    type: 'T-Shirts',
    image: 'https://images.pexels.com/photos/1032110/pexels-photo-1032110.jpeg',
  },

  // Mugs (10) - Nescafe Style
  {
    id: 201,
    name: 'Classic Coffee Mug',
    price: 349,
    type: 'Mugs',
    image: 'https://images.pexels.com/photos/4792391/pexels-photo-4792391.jpeg',
  },
  {
    id: 202,
    name: 'Nescafe Gold Mug',
    price: 399,
    type: 'Mugs',
    image: 'https://images.pexels.com/photos/851555/pexels-photo-851555.jpeg',
  },
  {
    id: 203,
    name: 'Minimalist Coffee Mug',
    price: 299,
    type: 'Mugs',
    image: 'https://images.pexels.com/photos/312418/pexels-photo-312418.jpeg',
  },
  {
    id: 204,
    name: 'Vintage Nescafe Mug',
    price: 449,
    type: 'Mugs',
    image: 'https://images.pexels.com/photos/905485/pexels-photo-905485.jpeg',
  },
  {
    id: 205,
    name: 'Ceramic Coffee Mug',
    price: 379,
    type: 'Mugs',
    image: 'https://images.pexels.com/photos/1727123/pexels-photo-1727123.jpeg',
  },
  {
    id: 206,
    name: 'Black Nescafe Mug',
    price: 499,
    type: 'Mugs',
    image: 'https://images.pexels.com/photos/887751/pexels-photo-887751.jpeg',
  },
  {
    id: 207,
    name: 'Glass Coffee Mug',
    price: 599,
    type: 'Mugs',
    image: 'https://images.pexels.com/photos/302899/pexels-photo-302899.jpeg',
  },
  {
    id: 208,
    name: 'Travel Coffee Mug',
    price: 699,
    type: 'Mugs',
    image: 'https://images.pexels.com/photos/2253275/pexels-photo-2253275.jpeg',
  },
  {
    id: 209,
    name: 'Espresso Nescafe Mug',
    price: 549,
    type: 'Mugs',
    image: 'https://images.pexels.com/photos/5587028/pexels-photo-5587028.jpeg',
  },
  {
    id: 210,
    name: 'Double-Wall Coffee Mug',
    price: 649,
    type: 'Mugs',
    image: 'https://images.pexels.com/photos/374147/pexels-photo-374147.jpeg',
  },

  // Posters (10)
  {
    id: 301,
    name: 'Vintage Movie Poster',
    price: 499,
    type: 'Posters',
    image: 'https://images.pexels.com/photos/33129/popcorn-movie-party-entertainment.jpg',
  },
  {
    id: 302,
    name: 'Motivational Quote Poster',
    price: 399,
    type: 'Posters',
    image: 'https://images.pexels.com/photos/733856/pexels-photo-733856.jpeg',
  },
  {
    id: 303,
    name: 'Space Exploration Poster',
    price: 599,
    type: 'Posters',
    image: 'https://images.pexels.com/photos/2150/sky-space-dark-galaxy.jpg',
  },
  {
    id: 304,
    name: 'Abstract Art Poster',
    price: 449,
    type: 'Posters',
    image: 'https://images.pexels.com/photos/1021876/pexels-photo-1021876.jpeg',
  },
  {
    id: 305,
    name: 'Travel Destination Poster',
    price: 549,
    type: 'Posters',
    image: 'https://images.pexels.com/photos/672532/pexels-photo-672532.jpeg',
  },
  {
    id: 306,
    name: 'Music Band Poster',
    price: 499,
    type: 'Posters',
    image: 'https://images.pexels.com/photos/167491/pexels-photo-167491.jpeg',
  },
  {
    id: 307,
    name: 'Minimalist Landscape Poster',
    price: 399,
    type: 'Posters',
    image: 'https://images.pexels.com/photos/417074/pexels-photo-417074.jpeg',
  },
  {
    id: 308,
    name: 'Wildlife Photography Poster',
    price: 649,
    type: 'Posters',
    image: 'https://images.pexels.com/photos/145939/pexels-photo-145939.jpeg',
  },
  {
    id: 309,
    name: 'Retro Gaming Poster',
    price: 599,
    type: 'Posters',
    image: 'https://images.pexels.com/photos/163036/mario-luigi-yoschi-figures-163036.jpeg',
  },
  {
    id: 310,
    name: 'Galaxy Nebula Poster',
    price: 699,
    type: 'Posters',
    image: 'https://images.pexels.com/photos/2150/sky-space-dark-galaxy.jpg',
  },

  // Stickers (10)
  {
    id: 401,
    name: 'Funny Cat Sticker Pack',
    price: 199,
    type: 'Stickers',
    image: 'https://images.pexels.com/photos/617278/pexels-photo-617278.jpeg',
  },
  {
    id: 402,
    name: 'Boho Floral Stickers',
    price: 149,
    type: 'Stickers',
    image: 'https://images.pexels.com/photos/462118/pexels-photo-462118.jpeg',
  },
  {
    id: 403,
    name: 'Space-Themed Stickers',
    price: 249,
    type: 'Stickers',
    image: 'https://images.pexels.com/photos/2150/sky-space-dark-galaxy.jpg',
  },
  {
    id: 404,
    name: 'Waterproof Laptop Stickers',
    price: 299,
    type: 'Stickers',
    image: 'https://images.pexels.com/photos/1591447/pexels-photo-1591447.jpeg',
  },
  {
    id: 405,
    name: 'Vinyl Decal Stickers',
    price: 179,
    type: 'Stickers',
    image: 'https://images.pexels.com/photos/159711/books-bookstore-book-reading-159711.jpeg',
  },
  {
    id: 406,
    name: 'Cartoon Character Stickers',
    price: 219,
    type: 'Stickers',
    image: 'https://images.pexels.com/photos/161559/background-bitter-breakfast-bright-161559.jpeg',
  },
  {
    id: 407,
    name: 'Glow-in-the-Dark Stickers',
    price: 349,
    type: 'Stickers',
    image: 'https://images.pexels.com/photos/1021876/pexels-photo-1021876.jpeg',
  },
  {
    id: 408,
    name: 'Holographic Sticker Pack',
    price: 399,
    type: 'Stickers',
    image: 'https://images.pexels.com/photos/3266700/pexels-photo-3266700.jpeg',
  },
  {
    id: 409,
    name: 'Custom Name Stickers',
    price: 279,
    type: 'Stickers',
    image: 'https://images.pexels.com/photos/2735981/pexels-photo-2735981.jpeg',
  },
  {
    id: 410,
    name: 'Emoji Sticker Collection',
    price: 199,
    type: 'Stickers',
    image: 'https://images.pexels.com/photos/2377565/pexels-photo-2377565.jpeg',
  },
];
      await Product.insertMany(initialProducts);
      console.log('Products seeded successfully!');
    }
  } catch (error) {
    console.error('Error seeding products:', error);
  }
};
seedProducts(); // Call the seeding function when the route file is loaded

// GET /api/products - Get all products with optional filtering and searching
router.get('/', async (req, res) => {
  try {
    let { type, search, manufacturerId } = req.query;
    let filter = {};

    if (type && type.toLowerCase() !== 'all') {
      filter.type = new RegExp(type, 'i'); // Case-insensitive type filter
    }

    if (search) {
      filter.$or = [
        { name: new RegExp(search, 'i') }, // Case-insensitive name search
        { type: new RegExp(search, 'i') }  // Case-insensitive type search
      ];
    }

    // Add manufacturerId filter if provided
    if (manufacturerId) {
      filter.manufacturerId = manufacturerId;
    }

    const products = await Product.find(filter);
    res.json(products);
  } catch (error) {
    console.error('Error fetching products:', error);
    res.status(500).json({ message: 'Server error fetching products.' });
  }
});

// GET /api/products/:id - Get a single product by ID
router.get('/:id', async (req, res) => {
  try {
    const product = await Product.findOne({ id: req.params.id });
    if (!product) {
      return res.status(404).json({ message: 'Product not found' });
    }
    res.json(product);
  } catch (error) {
    console.error('Error fetching product by ID:', error);
    res.status(500).json({ message: 'Server error fetching product.' });
  }
});

// POST /api/products - Add a new product (requires authentication/authorization)
router.post('/', async (req, res) => {
  const { id, name, price, type, image, manufacturerId } = req.body; // Ensure manufacturerId is sent from frontend

  if (!id || !name || !price || !type || !manufacturerId) {
    return res.status(400).json({ message: 'Please provide ID, name, price, type, and manufacturerId.' });
  }

  try {
    const existingProduct = await Product.findOne({ id });
    if (existingProduct) {
      return res.status(400).json({ message: 'Product with this ID already exists.' });
    }

    const newProduct = new Product({
      id,
      name,
      price,
      type,
      image,
      manufacturerId, // Save the manufacturer ID with the product
    });
    await newProduct.save();
    res.status(201).json(newProduct);
  } catch (error) {
    console.error('Error adding product:', error);
    res.status(500).json({ message: 'Server error adding product.' });
  }
});

// PUT /api/products/:id - Update a product by ID (requires authentication/authorization)
router.put('/:id', async (req, res) => {
  const { name, price, type, image, manufacturerId } = req.body; // Allow updating manufacturerId if needed
  try {
    const updatedProduct = await Product.findOneAndUpdate(
      { id: req.params.id }, // Find by 'id' field
      { name, price, type, image, manufacturerId },
      { new: true } // Return the updated document
    );
    if (!updatedProduct) {
      return res.status(404).json({ message: 'Product not found' });
    }
    res.json(updatedProduct);
  } catch (error) {
    console.error('Error updating product:', error);
    res.status(500).json({ message: 'Server error updating product.' });
  }
});

// DELETE /api/products/:id - Delete a product by ID (requires authentication/authorization)
router.delete('/:id', async (req, res) => {
  try {
    const deletedProduct = await Product.findOneAndDelete({ id: req.params.id }); // Find by 'id' field
    if (!deletedProduct) {
      return res.status(404).json({ message: 'Product not found' });
    }
    res.json({ message: 'Product deleted successfully' });
  } catch (error) {
    console.error('Error deleting product:', error);
    res.status(500).json({ message: 'Server error deleting product.' });
  }
});

module.exports = router;
